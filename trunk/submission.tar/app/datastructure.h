typedef struct si{
  int primary
  unsigned int id;
  unsigned char * message;
} server_instance;
